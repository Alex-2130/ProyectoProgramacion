/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package excepciones;

/**
 *
 * @author Usuario
 */
public class BadAñoFundacion extends Exception{

    public BadAñoFundacion() {
        System.out.println("Año de fundacion incorrecto");
    }
    
}
