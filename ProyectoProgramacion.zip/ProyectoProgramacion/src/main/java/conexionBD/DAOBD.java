/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;

/**
 *
 * @author Usuario
 */
public interface DAOBD {
    
    public void registrar(Categoria objeto);
    public void modificar(Categoria objeto);
    public void eliminar(Categoria objeto);
    public void buscar(Categoria objeto);
    
}
