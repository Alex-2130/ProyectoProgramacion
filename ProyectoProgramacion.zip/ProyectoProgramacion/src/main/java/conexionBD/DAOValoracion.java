/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import Users.*;
import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOValoracion implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto){
        Valoracion valoracion = (Valoracion)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "valoracion values(?, ?, ?, ?)");
            
            insertar.setString(1, valoracion.getUsuario().getNombreUsuario());
            insertar.setDouble(2, valoracion.getEstrellas());
            insertar.setString(3, valoracion.getComentario());
            insertar.setString(4, valoracion.getNombreLugar());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto){
        Valoracion valoracion = (Valoracion)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "valoracion set estrellas = ? where nombreUsuario = ?");
            
            modificar.setDouble(1, valoracion.getEstrellas());
            modificar.setString(2, valoracion.getUsuario().getNombreUsuario());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto){
        Valoracion valoracion = (Valoracion)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " valoracion where nombreUsuario = ?");
            
            eliminar.setString(1, valoracion.getUsuario().getNombreUsuario());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public String leer(){
        String valoraciones = "";
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from valoracion");
            
            while (consulta.next()){
                valoraciones += "\nNobre de usuario: " + consulta.getString("nombreUsuario")
                        + "\nNombre del lugar: " + consulta.getString("nombreLugar")
                        + "\nComentario: " + consulta.getString("comentario")
                        + "\nEstrellas: " + consulta.getDouble("estrellas") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return valoraciones;
    }

}
