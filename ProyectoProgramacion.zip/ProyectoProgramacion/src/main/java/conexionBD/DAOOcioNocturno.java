/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOOcioNocturno implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        OcioNocturno on = (OcioNocturno)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "ocionocturno values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setInt(1, on.getEdad());
            insertar.setString(2, on.getReserva());
            insertar.setString(3, on.getLista());
            insertar.setString(4, on.getHorario());
            insertar.setString(5, on.getServicios());
            insertar.setString(6, on.getWeb());
            insertar.setString(7, on.getName());
            insertar.setString(8, on.getDecripcion());
            insertar.setString(9, on.getTransporte());
            insertar.setBoolean(10, on.getEntrada());
            insertar.setDouble(11, on.getLatitud());
            insertar.setDouble(12, on.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        OcioNocturno on = (OcioNocturno)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "ocionocturno set horario = ? where nombre = ?");
            
            modificar.setString(1, on.getHorario());
            modificar.setString(2, on.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        OcioNocturno on = (OcioNocturno)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " ocionocturno where nombre = ?");
            
            eliminar.setString(1, on.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void buscar(Object objeto) {
        OcioNocturno on = (OcioNocturno)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement buscar = conectar.prepareStatement("select * "
                    + "from ocionocturno where nombre = ?");
            
            buscar.setString(1, on.getName());
            ResultSet consulta = buscar.executeQuery();
            
            if(consulta.next()){
                on.setEdad(consulta.getInt("edad"));
                on.setReserva(consulta.getString("reserva"));
                on.setLista(consulta.getString("lista"));
                on.setHorario(consulta.getString("horario"));
                on.setServicios(consulta.getString("servicios"));
                on.setWeb(consulta.getString("web"));
                on.setName(consulta.getString("nombre"));
                on.setDecripcion(consulta.getString("descripcion"));
                on.setTransporte(consulta.getString("transporte"));
                on.setEntrada(consulta.getBoolean("entrada"));
                on.setLatitud(consulta.getDouble("latitud"));
                on.setLongitud(consulta.getDouble("longitud"));
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
}
