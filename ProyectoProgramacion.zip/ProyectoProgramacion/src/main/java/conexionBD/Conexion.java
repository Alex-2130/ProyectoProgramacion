/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Usuario
 */
public class Conexion {
    
    private Conexion(){
        
    }
    //variable para guardar el estado de la conexion
    protected static Connection conexion;
    //variable para crear una instancia
    protected static Conexion instancia;
    //variables para poder conectarnos a la BD
    protected static final String url = "jdbc:mysql://localhost/bd_nazarigo";
    protected static final String username = "root";
    protected static final String password = "";
    
    public Connection conectar(){
        try {
            conexion = DriverManager.getConnection(url, username, password);
            
            return conexion;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return conexion;
    }
    
    public void cerrarConexion() throws SQLException{
        try {
            conexion.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            conexion.close();
        } finally {
            conexion.close();
        }
    }
    
    public static Conexion getInstancia(){
        if(instancia == null){
            instancia = new Conexion();
        }
        
        return instancia;
    }
}
