/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOCultural implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "evento_cultural values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, cultural.getHistoria());
            insertar.setString(2, cultural.getFestividad());
            insertar.setString(3, cultural.getDuracion());
            insertar.setString(4, cultural.getCoste());
            insertar.setInt(5, cultural.getAforo());
            insertar.setString(6, cultural.getHorario());
            insertar.setString(7, cultural.getServicios());
            insertar.setString(8, cultural.getWeb());
            insertar.setString(9, cultural.getName());
            insertar.setString(10, cultural.getDecripcion());
            insertar.setString(11, cultural.getTransporte());
            insertar.setBoolean(12, cultural.getEntrada());
            insertar.setDouble(13, cultural.getLatitud());
            insertar.setDouble(14, cultural.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "evento_cultural set horario = ? where nombre = ?");
            
            modificar.setString(1, cultural.getHorario());
            modificar.setString(2, cultural.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " evento_cultural where nombre = ?");
            
            eliminar.setString(1, cultural.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void buscar(Object objeto) {
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement buscar = conectar.prepareStatement("select * "
                    + "from evento_cultural where nombre = ?");
            
            buscar.setString(1, cultural.getName());
            ResultSet consulta = buscar.executeQuery();
            
            if(consulta.next()){
                cultural.setHistoria(consulta.getString("historia"));
                cultural.setFestividad(consulta.getString("festividad"));
                cultural.setDuracion(consulta.getString("duracion"));
                cultural.setCoste(consulta.getString("coste"));
                cultural.setAforo(consulta.getInt("aforo"));
                cultural.setHorario(consulta.getString("horario"));
                cultural.setServicios(consulta.getString("servicios"));
                cultural.setWeb(consulta.getString("web"));
                cultural.setName(consulta.getString("nombre"));
                cultural.setDecripcion(consulta.getString("descripcion"));
                cultural.setTransporte(consulta.getString("transporte"));
                cultural.setEntrada(consulta.getBoolean("entrada"));
                cultural.setLatitud(consulta.getDouble("latitud"));
                cultural.setLongitud(consulta.getDouble("longitud"));
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
}
