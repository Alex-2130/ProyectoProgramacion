/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOCultural implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "evento_cultural values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, cultural.getHistoria());
            insertar.setString(2, cultural.getFestividad());
            insertar.setString(3, cultural.getDuracion());
            insertar.setString(4, cultural.getCoste());
            insertar.setInt(5, cultural.getAforo());
            insertar.setString(6, cultural.getHorario());
            insertar.setString(7, cultural.getServicios());
            insertar.setString(8, cultural.getWeb());
            insertar.setString(9, cultural.getName());
            insertar.setString(10, cultural.getDecripcion());
            insertar.setString(11, cultural.getTransporte());
            insertar.setBoolean(12, cultural.getEntrada());
            insertar.setDouble(13, cultural.getLatitud());
            insertar.setDouble(14, cultural.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "evento_cultural set horario = ? where nombre = ?");
            
            modificar.setString(1, cultural.getHorario());
            modificar.setString(2, cultural.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Cultural cultural = (Cultural)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " evento_cultural where nombre = ?");
            
            eliminar.setString(1, cultural.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String leer(){
        String eventosCulturales = "";
        
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from evento_cultural");
            
            while (consulta.next()){
                eventosCulturales += "\nNombre: " + consulta.getString("nombre")
                        + "\nHistoria: " + consulta.getString("historia") 
                        + "\nDescripcion: " + consulta.getString("descripcion") 
                        + "\nFestividad: " + consulta.getString("festividad") 
                        + "\nDuracion: " + consulta.getString("duracion") 
                        + "\nCoste: " + consulta.getString("coste") 
                        + "\nAforo: " + consulta.getInt("aforo") 
                        + "\nHorario: " + consulta.getString("horario")
                        + "\nServicios: " + consulta.getString("servicios")
                        + "\nWeb: " + consulta.getString("web")
                        + "\nTransporte: " + consulta.getString("transporte")
                        + "\nEntrada: " + consulta.getBoolean("entrada")
                        + "\nLatitud: " + consulta.getDouble("latitud")
                        + "\nLongitud: " + consulta.getDouble("longitud") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
        return eventosCulturales;
    }
    
}
