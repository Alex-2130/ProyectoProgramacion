/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import Users.Usuario;
import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOUsuario implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto){
        Usuario usuario = (Usuario)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "usuario values(?, ?, ?)");
            
            insertar.setString(1, usuario.getNombreUsuario());
            insertar.setString(2, usuario.getCorreo());
            insertar.setString(3, usuario.getContraseña());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto){
        Usuario usuario = (Usuario)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "usuario set correo = ? where nombre = ?");
            
            modificar.setString(1, usuario.getCorreo());
            modificar.setString(2, usuario.getNombreUsuario());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto){
        Usuario usuario = (Usuario)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " usuario where nombre = ?");
            
            eliminar.setString(1, usuario.getNombreUsuario());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String leer(){
        String usuarios = "";
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from usuario");
            
            while (consulta.next()){
                usuarios += "\nNobre de usuario: " + consulta.getString("nombreUsuario")
                        + "\nCorreo: " + consulta.getString("correo")
                        + "\nContraseña: " + consulta.getString("contraseña") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return usuarios;
    }
    
    public String obtenerContraseña(String nombreUsuario){
        try{
            Connection conectar = conexion.conectar();
            PreparedStatement consulta = conectar.prepareStatement("select * "
                    + "from usuario where nombre = ? ");
            
            consulta.setString(1, nombreUsuario);
            
            ResultSet consulta1 = consulta.executeQuery();
            
            while (consulta1.next()){
                return consulta1.getString("contraseña");
            }
            
            conexion.cerrarConexion();
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return "";
    }
    
}
