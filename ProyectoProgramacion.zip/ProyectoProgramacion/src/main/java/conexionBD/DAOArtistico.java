/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOArtistico implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Artistico artistico = (Artistico)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "evento_artistico values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, artistico.getArtista());
            insertar.setString(2, artistico.getTipo());
            insertar.setString(3, artistico.getDuracion());
            insertar.setString(4, artistico.getCoste());
            insertar.setInt(5, artistico.getAforo());
            insertar.setString(6, artistico.getHorario());
            insertar.setString(7, artistico.getServicios());
            insertar.setString(8, artistico.getWeb());
            insertar.setString(9, artistico.getName());
            insertar.setString(10, artistico.getDecripcion());
            insertar.setString(11, artistico.getTransporte());
            insertar.setBoolean(12, artistico.getEntrada());
            insertar.setDouble(13, artistico.getLatitud());
            insertar.setDouble(14, artistico.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Artistico artistico = (Artistico)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "evento_artistico set horario = ? where nombre = ?");
            
            modificar.setString(1, artistico.getHorario());
            modificar.setString(2, artistico.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Artistico artistico = (Artistico)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " evento_artistico where nombre = ?");
            
            eliminar.setString(1, artistico.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void buscar(Object objeto) {
        Artistico artistico = (Artistico)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement buscar = conectar.prepareStatement("select * "
                    + "from evento_artistico where nombre = ?");
            
            buscar.setString(1, artistico.getName());
            ResultSet consulta = buscar.executeQuery();
            
            if(consulta.next()){
                artistico.setArtista(consulta.getString("artista"));
                artistico.setTipo(consulta.getString("tipo"));
                artistico.setDuracion(consulta.getString("duracion"));
                artistico.setCoste(consulta.getString("coste"));
                artistico.setAforo(consulta.getInt("aforo"));
                artistico.setHorario(consulta.getString("horario"));
                artistico.setServicios(consulta.getString("servicios"));
                artistico.setWeb(consulta.getString("web"));
                artistico.setName(consulta.getString("nombre"));
                artistico.setDecripcion(consulta.getString("descripcion"));
                artistico.setTransporte(consulta.getString("transporte"));
                artistico.setEntrada(consulta.getBoolean("entrada"));
                artistico.setLatitud(consulta.getDouble("latitud"));
                artistico.setLongitud(consulta.getDouble("longitud"));
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
}
