/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOPuntoDeInteres implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        PuntoDeInteres ptinteres = (PuntoDeInteres)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "punto_de_interes values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, ptinteres.getAñoFundacion());
            insertar.setString(2, ptinteres.getTipo());
            insertar.setString(3, ptinteres.getVista());
            insertar.setString(4, ptinteres.getName());
            insertar.setString(5, ptinteres.getDecripcion());
            insertar.setString(6, ptinteres.getTransporte());
            insertar.setBoolean(7, ptinteres.getEntrada());
            insertar.setDouble(8, ptinteres.getLatitud());
            insertar.setDouble(9, ptinteres.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        PuntoDeInteres ptinteres = (PuntoDeInteres)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "punto_de_interes set transporte = ? where nombre = ?");
            
            modificar.setString(1, ptinteres.getTransporte());
            modificar.setString(2, ptinteres.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        PuntoDeInteres ptinteres = (PuntoDeInteres)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " punto_de_interes where nombre = ?");
            
            eliminar.setString(1, ptinteres.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String leer(){
        String ptoInteres = "";
        
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from punto_de_interes");
            
            while (consulta.next()){
                ptoInteres += "\nNombre: " + consulta.getString("nombre")
                        + "\nTipo: " + consulta.getString("tipo") 
                        + "\nAño de fundacion: " + consulta.getString("añoFundacion") 
                        + "\nVistas: " + consulta.getString("vista") 
                        + "\nDescripcion: " + consulta.getString("descripcion") 
                        + "\nTransporte: " + consulta.getString("transporte")
                        + "\nEntrada: " + consulta.getBoolean("entrada")
                        + "\nLatitud: " + consulta.getDouble("latitud")
                        + "\nLongitud: " + consulta.getDouble("longitud") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
        return ptoInteres;
    }
    
}
