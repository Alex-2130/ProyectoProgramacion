/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAOBar implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Bar bar = (Bar)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "bar values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setBoolean(1, bar.isTapasAElegir());
            insertar.setBoolean(2, bar.isJuegosDeMesa());
            insertar.setBoolean(3, bar.isDeportes());
            insertar.setString(4, bar.getHorario());
            insertar.setString(5, bar.getServicios());
            insertar.setString(6, bar.getWeb());
            insertar.setString(7, bar.getName());
            insertar.setString(8, bar.getDecripcion());
            insertar.setString(9, bar.getTransporte());
            insertar.setBoolean(10, bar.getEntrada());
            insertar.setDouble(11, bar.getLatitud());
            insertar.setDouble(12, bar.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Bar bar = (Bar)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update bar "
                    + "set horario = ? where nombre = ?");
            
            modificar.setString(1, bar.getHorario());
            modificar.setString(2, bar.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Bar bar = (Bar)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " bar where nombre = ?");
            
            eliminar.setString(1, bar.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String leer(){
        String bares = "";
        
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from bar");
            
            while (consulta.next()){
                bares += "\nNombre: " + consulta.getString("nombre")
                        + "\nDescripcion: " + consulta.getString("descripcion") 
                        + "\nHorario: " + consulta.getString("horario")
                        + "\nServicios: " + consulta.getString("servicios")
                        + "\nWeb: " + consulta.getString("web")
                        + "\nDeportes: " + consulta.getBoolean("deportes")
                        + "\nTapas a elegir: " + consulta.getBoolean("tapasAElegir") 
                        + "\nJuegos de mesa: " + consulta.getBoolean("juegosDeMesa")
                        + "\nTransporte: " + consulta.getString("transporte")
                        + "\nEntrada: " + consulta.getBoolean("entrada")
                        + "\nLatitud: " + consulta.getDouble("latitud")
                        + "\nLongitud: " + consulta.getDouble("longitud") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
        return bares;
    }
    
}
