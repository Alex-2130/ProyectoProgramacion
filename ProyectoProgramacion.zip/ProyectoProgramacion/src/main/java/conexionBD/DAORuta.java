/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAORuta implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Ruta ruta = (Ruta)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "ruta values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, ruta.getDistancia());
            insertar.setString(2, ruta.getHorarioRecomendado());
            insertar.setString(3, ruta.getMovilidad());
            insertar.setString(4, ruta.getAñoFundacion());
            insertar.setString(5, ruta.getTipo());
            insertar.setString(6, ruta.getVista());
            insertar.setString(7, ruta.getName());
            insertar.setString(8, ruta.getDecripcion());
            insertar.setString(9, ruta.getTransporte());
            insertar.setBoolean(10, ruta.getEntrada());
            insertar.setDouble(11, ruta.getLatitud());
            insertar.setDouble(12, ruta.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        Ruta ruta = (Ruta)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "ruta set transporte = ? where nombre = ?");
            
            modificar.setString(1, ruta.getTransporte());
            modificar.setString(2, ruta.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Ruta ruta = (Ruta)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " ruta where nombre = ?");
            
            eliminar.setString(1, ruta.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void buscar(Object objeto) {
        Ruta ruta = (Ruta)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement buscar = conectar.prepareStatement("select * "
                    + "from ruta where nombre = ?");
            
            buscar.setString(1, ruta.getName());
            ResultSet consulta = buscar.executeQuery();
            
            if(consulta.next()){
                ruta.setDistancia(consulta.getString("distancia"));
                ruta.setHorarioRecomendado(consulta.getString("horarioRecomendado"));
                ruta.setMovilidad(consulta.getString("movilidad"));
                ruta.setAñoFundacion(consulta.getString("añoFundacion"));
                ruta.setTipo(consulta.getString("tipo"));
                ruta.setVista(consulta.getString("vista"));
                ruta.setName(consulta.getString("nombre"));
                ruta.setDecripcion(consulta.getString("descripcion"));
                ruta.setTransporte(consulta.getString("transporte"));
                ruta.setEntrada(consulta.getBoolean("entrada"));
                ruta.setLatitud(consulta.getDouble("latitud"));
                ruta.setLongitud(consulta.getDouble("longitud"));
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
    
}
