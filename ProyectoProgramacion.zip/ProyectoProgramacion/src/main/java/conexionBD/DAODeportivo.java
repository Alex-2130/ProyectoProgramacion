/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAODeportivo implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "evento_deportivo values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, deportivo.getTipoDeDeporte());
            insertar.setString(2, deportivo.getTipoDeCompeticion());
            insertar.setString(3, deportivo.getDuracion());
            insertar.setString(4, deportivo.getCoste());
            insertar.setInt(5, deportivo.getAforo());
            insertar.setString(6, deportivo.getHorario());
            insertar.setString(7, deportivo.getServicios());
            insertar.setString(8, deportivo.getWeb());
            insertar.setString(9, deportivo.getName());
            insertar.setString(10, deportivo.getDecripcion());
            insertar.setString(11, deportivo.getTransporte());
            insertar.setBoolean(12, deportivo.getEntrada());
            insertar.setDouble(13, deportivo.getLatitud());
            insertar.setDouble(14, deportivo.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "evento_deportivo set horario = ? where nombre = ?");
            
            modificar.setString(1, deportivo.getHorario());
            modificar.setString(2, deportivo.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " evento_deportivo where nombre = ?");
            
            eliminar.setString(1, deportivo.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void buscar(Object objeto) {
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement buscar = conectar.prepareStatement("select * "
                    + "from evento_deportivo where nombre = ?");
            
            buscar.setString(1, deportivo.getName());
            ResultSet consulta = buscar.executeQuery();
            
            if(consulta.next()){
                deportivo.setTipoDeDeporte(consulta.getString("tipoDeDeporte"));
                deportivo.setTipoDeCompeticion(consulta.getString("tipoDeCompeticion"));
                deportivo.setDuracion(consulta.getString("duracion"));
                deportivo.setCoste(consulta.getString("coste"));
                deportivo.setAforo(consulta.getInt("aforo"));
                deportivo.setHorario(consulta.getString("horario"));
                deportivo.setServicios(consulta.getString("servicios"));
                deportivo.setWeb(consulta.getString("web"));
                deportivo.setName(consulta.getString("nombre"));
                deportivo.setDecripcion(consulta.getString("descripcion"));
                deportivo.setTransporte(consulta.getString("transporte"));
                deportivo.setEntrada(consulta.getBoolean("entrada"));
                deportivo.setLatitud(consulta.getDouble("latitud"));
                deportivo.setLongitud(consulta.getDouble("longitud"));
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }
}
