/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionBD;

import izv.proyectoprogramacion.*;
import java.sql.*;

/**
 *
 * @author Usuario
 */
public class DAODeportivo implements DAOBD{
    
    Conexion conexion = Conexion.getInstancia();

    @Override
    public void registrar(Object objeto) {
        
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement insertar = conectar.prepareStatement("insert into "
                    + "evento_deportivo values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            insertar.setString(1, deportivo.getTipoDeDeporte());
            insertar.setString(2, deportivo.getTipoDeCompeticion());
            insertar.setString(3, deportivo.getDuracion());
            insertar.setString(4, deportivo.getCoste());
            insertar.setInt(5, deportivo.getAforo());
            insertar.setString(6, deportivo.getHorario());
            insertar.setString(7, deportivo.getServicios());
            insertar.setString(8, deportivo.getWeb());
            insertar.setString(9, deportivo.getName());
            insertar.setString(10, deportivo.getDecripcion());
            insertar.setString(11, deportivo.getTransporte());
            insertar.setBoolean(12, deportivo.getEntrada());
            insertar.setDouble(13, deportivo.getLatitud());
            insertar.setDouble(14, deportivo.getLongitud());
            insertar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void modificar(Object objeto) {
        
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement modificar = conectar.prepareStatement("update "
                    + "evento_deportivo set horario = ? where nombre = ?");
            
            modificar.setString(1, deportivo.getHorario());
            modificar.setString(2, deportivo.getName());
            modificar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
    }

    @Override
    public void eliminar(Object objeto) {
        Deportivo deportivo = (Deportivo)objeto;
        
        try{
            Connection conectar = conexion.conectar();
            
            PreparedStatement eliminar = conectar.prepareStatement("delete from"
                    + " evento_deportivo where nombre = ?");
            
            eliminar.setString(1, deportivo.getName());
            eliminar.executeUpdate();
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public String leer(){
        String eventosDeportivos = "";
        
        try{
            Connection conectar = conexion.conectar();
            Statement stmt = conectar.createStatement();
            ResultSet consulta = stmt.executeQuery("select * from evento_deportivo");
            
            while (consulta.next()){
                eventosDeportivos += "\nNombre: " + consulta.getString("nombre")
                        + "\nTipo de deporte: " + consulta.getString("tipoDeDeporte") 
                        + "\nTipo de competicion: " + consulta.getString("tipoDeCompeticion") 
                        + "\nFestividad: " + consulta.getString("festividad") 
                        + "\nDuracion: " + consulta.getString("duracion") 
                        + "\nCoste: " + consulta.getString("coste") 
                        + "\nAforo: " + consulta.getInt("aforo") 
                        + "\nHorario: " + consulta.getString("horario")
                        + "\nServicios: " + consulta.getString("servicios")
                        + "\nWeb: " + consulta.getString("web")
                        + "\nTransporte: " + consulta.getString("transporte")
                        + "\nEntrada: " + consulta.getBoolean("entrada")
                        + "\nLatitud: " + consulta.getDouble("latitud")
                        + "\nLongitud: " + consulta.getDouble("longitud") + "\n";
            }
            
            conexion.cerrarConexion();
            
        } catch (SQLException e){
            System.out.println(e.getMessage());
        }
        
        return eventosDeportivos;
    }
}
