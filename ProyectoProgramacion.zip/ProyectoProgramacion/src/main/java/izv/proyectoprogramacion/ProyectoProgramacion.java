/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package izv.proyectoprogramacion;

import Interfaz.Login;
import Users.Usuario;
import conexionBD.*;
    

/**
 *
 * @author Mañana
 */
public class ProyectoProgramacion {

    public static void main(String[] args) {
        //Se nos ejecutará la unidad de interfaz gráfica cada vez que ejecutemos
        //el programa a la misma vez
        addGui();
        addOcio();
        addEvento();
        addPinteres();
        addRuta();
        
    }

    public static void addGui() {
        Login inicio = new Login();
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
    }

    public static void addOcio() {

        //Añadimos Todos los locales nocturnos y Bares que estarán disponibles en nuestra APP
        OcioNocturno local1 = new OcioNocturno(18, "Reservas: Disponibles",
                "Lista: Exclusiva",
                "Lunes a Viernes: 22:00 - 6:30 Festivos y Fines de semana:"
                + " 22:00 - 7:00",
                "Servicios: Coctelería y Cachimbas",
                "https://maewestgranada.com/",
                "Mae West Granada",
                "DJs y cócteles en una bulliciosa discoteca con varias barras y"
                + " pistas de bailes, además de terraza.",
                "Acceso mediante transporte público y taxis disponibles para la "
                + "vuelta."
                + " Cuenta con áreas de estacionamiento cercanas\n",
                true, 0, 0);

        OcioNocturno local2 = new OcioNocturno(18, "Reservas: Disponibles",
                "Lista: Disponible",
                "Jueves a Domingo 23:00 - 6:30",
                "Servicios: Coctelería y Cachimbas",
                "https://dsokogranada.es/",
                "Dsoko Granada",
                "DJs y cócteleria con varias barras y pista de baile, "
                + "además de terraza.",
                "Acceso mediante transporte público y taxis disponibles para la "
                + "vuelta."
                + " Cuenta con áreas de estacionamiento cercanas\n",
                true, 0, 0);

        OcioNocturno local3 = new OcioNocturno(18, "Reservas: Disponibles",
                "Lista: Disponible y Publica",
                "Lunes a Sábado: 00:00 - 6:30",
                "Servicios: Coctelería, cachimbas y Eventos",
                "https://discotecagranada10.com/",
                "Teatro Granada Diez",
                "Música, cócteles, cerveza y sesiones de DJs en una"
                + " popular discoteca con efectos de luces.",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.",
                true, 0, 0);

        OcioNocturno local4 = new OcioNocturno(18, "Reserva: Disponible"
                + " para Terraza en horario café",
                "Lista: No",
                "Lunes a Domingo: 16:00 - 4:00",
                "Servicios: Coctelería, cachimbas y café",
                "https://www.instagram.com/atrivmgranada/?hl=es",
                "PUB Atrivm Granada",
                "Música, cócteles, cerveza, café y sesiones de DJs en una",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.",
                false, 0, 0);

        OcioNocturno local5 = new OcioNocturno(18, "Reservas: No",
                "Lista: No",
                "Lunes a Domingo: 22:00 - 4:00",
                "Servicios: Coctelería y cachimbas",
                "https://www.parabarap.com/?srsltid=AfmBOoq-rSlxtJ-Mo8rgqKv1mri4eSsebZpv4W8GEkSrKWxpeD3z-5er",
                "PUB Parabarap",
                "Parabarap en es un modelo de Negocio por y para "
                + "tod@s que nunca deja de sorprenderte y darte el PRECIO JUSTO",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.",
                false, 0, 0);

        OcioNocturno local6 = new OcioNocturno(16, "Reservas: No",
                "Lista: No",
                "Miércoles a Sábado: 21:00 - 4:00",
                "Servicios: Merchandising, Coctelería, Cervezas importadas"
                + " artesanas, Billar, Futbolín, Dardos y Videoconsolas",
                "https://www.instagram.com/namekpub/?hl=es",
                "Namek Granada",
                "Namek en es un modelo de Negocio por y para "
                + "el mundo del frikismo que nunca deja de sorprenderte "
                + "y darte el PRECIO JUSTO, musica alternativa",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.",
                false, 0, 0);
        
        //creo una instancia para añadir ocio nocturno a la base de datos
        DAOOcioNocturno daoON = new DAOOcioNocturno();
        
//        daoON.registrar(local1);
//        daoON.registrar(local2);
//        daoON.registrar(local3);
//        daoON.registrar(local4);
//        daoON.registrar(local5);
//        daoON.registrar(local6);

        //esto es para eliminar los objetos de la base de datos
//        daoON.eliminar(local1);
//        daoON.eliminar(local2);
//        daoON.eliminar(local3);
//        daoON.eliminar(local4);
//        daoON.eliminar(local5);
//        daoON.eliminar(local6);

        Bar continental = new Bar(false, true, true,
                "16:00 - 1:00", "Coctelería, juegos de mesa, merienda,"
                + " billar, sala de baile para eventos",
                "https://www.instagram.com/continentalgranada/?hl=es",
                "Continental", "Somos un café-pub ubicado en Granada centro, "
                + "con más de 230 juegos de mesa,"
                + " 33 televisores, 3 mesas de billar ,salas privadas y "
                + "2 pantallas gigantes.",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.", false, 1.0, 0.1);
        Bar garden = new Bar(true, false, false,
                "8:00 - 00:00", "Cafetería, comidas y cenas",
                "http://www.gardentapasxxl.com/CodigoQR/Carta.pdf", "Garden",
                "Desenfadado y colorido local con fotomurales de "
                + "naturaleza para tapas, bocadillos y hamburguesas.",
                "Acceso mediante transporte público y taxis disponibles "
                + "para la vuelta.",
                false, 1.0, 1.0);
        Bar rhinBarril = new Bar(true, false, true,
                "Mañanas: Lunes a jueves 12:00 - 17:00 Tardes: 19:30 - 1:00"
                + "Viernes a Domingo 12:00 - 1:00", "Cervecería "
                + "artesana e importada, visualización de grandes"
                + "acontecimientos deportivos",
                "https://carta.menu/restaurants/granada-4/rhin-barril-ii",
                "Rhim Barril", "Rhin Barril se ha consolidado como un "
                + "referente de las tapas en Granada,"
                + " especialmente apreciado por estudiantes y locales."
                + " Su variada oferta de platos, desde carnes en salsa "
                + "hasta paellas, destaca por su buena relación calidad-"
                + "precio.",
                "Acceso mediante transporte público y taxis disponibles"
                + "para la vuelta.",
                false, 1.0, 1.0);
        
        //creo una instancia para añadir bares a la base de datos
        DAOBar daoBar = new DAOBar();
        
//        daoBar.registrar(continental);
//        daoBar.registrar(garden);
//        daoBar.registrar(rhinBarril);

        //esto es para eliminar los objetos de la base de datos
//        daoBar.eliminar(continental);
//        daoBar.eliminar(garden);
//        daoBar.eliminar(rhinBarril);

//        daoBar.leer();

    }

    public static void addEvento() {

        Artistico eArt1 = new Artistico("Morad", "Drill/Trap", "2h aprox", 
                "Entre 40 y 100 euros", 14500,
                "9 de Mayo", "Bar",
                "https://ticketrona.com/evento/morad-en-granada",
                "Plaza de Toros", "",
                "Acceso mediante transporte público y taxis disponibles ",
                true, 0, 0);

        Artistico eArt2 = new Artistico("Manuel Carrasco", "Pop flamenco",
                "2h aprox", "Entre 50 y 100 euros", 14500,
                "23 y 24 de Mayo", "bar",
                "https://provenue.es/granada/manuel-carrasco-2-fecha/",
                "Plaza de Toros", "Tour salvaje",
                "Acceso mediante transporte público y taxis disponibles",
                true, 0, 0);

        Artistico eArt3 = new Artistico("Myke Towers", "Urbana Latino",
                "2h aprox", "Entre 45 y 90 euros", 14500,
                "1 de Junio", "Bar",
                "https://provenue.es/granada/myke-towers/",
                "Plaza de Toros", "Europe Tour", "Acceso mediante"
                + " transporte público y taxis disponibles", true, 0, 0);
        
        //creo una instancia para añadir eventos artísticos a la base de datos
        DAOArtistico daoArtistico = new DAOArtistico();
        
//        daoArtistico.registrar(eArt1);
//        daoArtistico.registrar(eArt2);
//        daoArtistico.registrar(eArt3);

        //esto es para eliminar los objetos de la base de datos
//        daoArtistico.eliminar(eArt1);
//        daoArtistico.eliminar(eArt2);
//        daoArtistico.eliminar(eArt3);

        Cultural eCul1 = new Cultural("Corpus Christi: Celebración local, La fiesta"
                + " tiene sus raices en la conquista de Granada por los Reyes "
                + "Católicos en 1942 y se ha ido enriqueciendo con el paso de los "
                + "siglos", "Se celebra del 14 al 21 de Junio, destacando la Tarasca"
                + " día 18 y la procesión día 19", "Una semana", 
                "Gratuito", 15000, "14 al 21 de Junio",
                "Casetas, atracciones y restaurantes",
                "https://www.spain.info/es/agenda/corpus-christi-granada/",
                "Corpus Christi", "Teatro, zarzuela, conciertos, exposiciones y "
                + "espectáculos inundan la ciudad."
                + " Las casetas del recinto ferial se llenan de alegría y "
                + "música, mientras en la plaza de toros se desarrolla la "
                + "feria taurina.", "Lineas de autobus reservadas y"
                + "metropolitano disponible", false, 0, 0);

        Cultural eCul2 = new Cultural("Semana Santa: Celebración nacional, "
                + "es una celebración cultural y religiosa con raices en el siglo 16"
                + "donde se organizaron las primeras procesiones para compartir los"
                + "misterios de la pasión, muerte y resurrección de Jesucristo.",
                "Se celebra del 13 al 20 de Abril aunque su celebración "
                + "varía cada año", "Una semana", "Gratuito", 30000, 
                "Mañanas y Tardes", "Tribunas y puestos ambulantes",
                "https://www.andalucia.org/eventos/semana-santa/granada/",
                "Semana Santa", "Al llegar a Andalucía en Semana Santa, uno "
                + "sólo debe dejarse seducir por sus propios sentidos: "
                + "respirar el aroma que impregna el ambiente,"
                + " mezcla de incienso y azahar; emocionarse con el canto"
                + " de una saeta o escuchar el silencio de una multitud "
                + "respetuosa...", "Transporte publico alrededores"
                + " del centro", false, 0, 0);

        Cultural eCul3 = new Cultural("Cruces: Celebración Autonómica con principal"
                + "repercusión en la ciudad de Granada, con la celebración de la festivida"
                + "religiosa y popular del día de la cruz", "Se celebra los"
                + " días 3 y 4 de Mayo", "2 días", "Grratuito", 20000,
                "Mañanas y tardes principalmente",
                "Cocteles, exposición de cruces y tapas",
                "https://www.granadadirect.com/fiestas/dia-cruz-granada/",
                "Día de la Cruz", "Para este día las calles, plazas, "
                + "patios e incluso escaparates se engalanan y se llenan "
                + "de maravillosos altares en honor a la Santa Cruz.",
                "Transporte público disponible", false, 0, 0);
        
        //creo una instancia para añadir eventos culturales a la base de datos
        DAOCultural daoCultural = new DAOCultural();
        
//        daoCultural.registrar(eCul1);
//        daoCultural.registrar(eCul2);
//        daoCultural.registrar(eCul3);

        //esto es para eliminar los objetos de la base de datos
//        daoCultural.eliminar(eCul1);
//        daoCultural.eliminar(eCul2);
//        daoCultural.eliminar(eCul3);

        Deportivo eDep1 = new Deportivo("Triatlón", "10º Sprint,"
                + "Universidad de Granada", "3h-4h", 
                "Gratuito", 10000, "8 de junio, 11:00", "",
                "https://deportes.ugr.es/competiciones/eventos-deportivos/triatlon-universidad",
                "Universidad de Granada", "750m natación, 23km bicicleta"
                + " 5km carrera", "Acceso con transporte público", false, 0, 0);

        Deportivo eDep2 = new Deportivo("Paddle Surf",
                "4º Campeonato", "3h-4h", 
                "Gratuito", 10000, "5 de abril 2025", "",
                "https://deportes.ugr.es/competiciones/eventos-deportivos/triatlon-universidad",
                "Universidad de Granada", "Una carrera de Larga Distancia"
                + " perteneciente al Circuito Andaluz de SUP y  puntuable"
                + " para la Liga Fesurfing Costa del Sup.",
                "Acceso mediante transporte público", false, 0, 0);

        Deportivo eDep3 = new Deportivo("Ciclismo",
                "Vuelta ciclista", "3 semanas", 
                "Gratuito", 10000, "Horario independiente a la "
                + "localidad de Granada", "", "https://www.lavuelta.es/es",
                "Vuelta Ciclista España", "", "Acceso mediante "
                + "transporte público", false, 0, 0);
        
        //creo una instancia para añadir eventos deportivos a la base de datos
        DAODeportivo daoDeportivo = new DAODeportivo();
        
//        daoDeportivo.registrar(eDep1);
//        daoDeportivo.registrar(eDep2);
//        daoDeportivo.registrar(eDep3);

        //esto es para eliminar los objetos de la base de datos
//        daoDeportivo.eliminar(eDep1);
//        daoDeportivo.eliminar(eDep2);
//        daoDeportivo.eliminar(eDep3);

    }

    public static void addPinteres() {

        PuntoDeInteres punto1 = new PuntoDeInteres("1525", "Mirador",
                "Alhambra, Sierra nevada y ciudad antigua", "Mirador de "
                + "San Nicolas", "https://miradorsanicolas.com/"
                + "Este mirador es una visita obligada para los turistas que "
                + "quieren maravillarse con la belleza de este enclave. "
                + "La iglesia de San Nicolás, el aljibe y la plaza ofrecen unas "
                + "vistas impresionantes de la Alhambra, la Sierra Nevada y la "
                + "ciudad antigua.", "Accesible mediante transporte público",
                false, 0, 0);

        PuntoDeInteres punto2 = new PuntoDeInteres("2014", "Museo",
                "Inquisición, carrera del darro", "Palacio de los Olvidados",
                "https://palaciodelosolvidados.es/ La selección de los instrumentos"
                + " de tortura y de pena capital, corresponde a los más"
                + " utilizados por los distintos tribunales inquisitoriales,"
                + " tanto eclesiásticos como civiles, en toda Europa.",
                "Acceso mediante transporte público unicamente cercanías",
                false, 0, 0);

        PuntoDeInteres punto3 = new PuntoDeInteres("1961", "Mirador",
                "Alhambra, Sierra Nevada y ciudad antigua",
                "Mirador de los Carvajales",
                "https://www.turgranada.es/es/pois/mirador-de-los-carvajales "
                + "Este escondido mirador se encuentra en la recoleta "
                + "Placeta de los Carvajales, en la parte baja del Albaicín"
                + " y muy cerca de las calles Calderería y sus teterías. ",
                "Acceso mediante transporte público unicamente cercanías",
                false, 0, 0);

        PuntoDeInteres punto4 = new PuntoDeInteres("1460", "Mercado/Zoco",
                "Casco antiguo", "Alcaicería", "Antiguo zoco o "
                + "mercado árabe, ubicado cerca de la Catedral y la calle"
                + " Reyes Católicos", "Acceso mediante transporte"
                + " público", false, 0, 0);

        PuntoDeInteres punto5 = new PuntoDeInteres("1349", "Palacio barroco",
                "Casco antiguo", "Palacio de la Madraza",
                "https://www.andalucia.org/listing/palacio-de-la-madraza/16287102/"
                + "Situado frente a la capilla real, el Palacio de la Madraza"
                + " fue la sede de la Escuela Musulmana de la Ley Coránica"
                + " que fundó Yusuf I. Tras la toma de la ciudad",
                "Acceso mediante transporte público", true, 0, 0);
        
        //creo una instancia para añadir puntos de interes a la base de datos
        DAOPuntoDeInteres daoPtoInteres = new DAOPuntoDeInteres();

//        daoPtoInteres.registrar(punto1);
//        daoPtoInteres.registrar(punto2);
//        daoPtoInteres.registrar(punto3);
//        daoPtoInteres.registrar(punto4);
//        daoPtoInteres.registrar(punto5);

        //esto es para eliminar los objetos de la base de datos
//        daoPtoInteres.eliminar(punto1);
//        daoPtoInteres.eliminar(punto2);   
//        daoPtoInteres.eliminar(punto3);
//        daoPtoInteres.eliminar(punto4);
//        daoPtoInteres.eliminar(punto5);
    }

    public static void addRuta() {
        Ruta ruta1 = new Ruta("550 metros", "10:00 - 12:00 17:00 - 20:00",
                "Andando", "Palacio Olvidos: 2014, Carvajales: "
                + "1961 y San Nicolas: 1525", "Museo y miradores",
                "Alhambra, Sierra nevada, Paseo de los tristes y ciudad antigua",
                "Ruta Turística Albayzín", "En esta ruta veremos el "
                + "museo de la inquisición, las maravillosas calles que "
                + "componen el albayzín y las preciosas vistas que nos "
                + "ofrence los miradores de Granada", "Accesible"
                + " mediante transporte público cercanías",
                true, 0, 0);

        Ruta ruta2 = new Ruta("200 metros", "10:00 - 12:00 "
                + "17:00 - 20:00", "Andando", "Zoco: 1460, "
                + "Palacio de la Madraza: 1349", "Mercado y Palacio",
                "Casco antiguo", "Ruta Turística comercios", "En"
                + " esta ruta contemplamos unas preciosas vistas de las "
                + "calles antiguas originarias del siglo XV",
                "Accesible mediante transporte públic", false, 0, 0);

        Ruta ruta3 = new Ruta("9,45 Km",
                "Comienzo: 9:00 - 11:00", "Andando",
                "No especificada", "Senderismo", "Paisaje natural",
                "Cahorros Monachil",
                "Un paraje de caprichosas esculturas naturales, creadas "
                + "por las crecidas de la cuenca fluvial, que han excavado"
                + " cuevas, bóvedas, paredes y formaciones rocosas a lo "
                + "largo del tiempo.", "Accesible mediante linea de bus "
                + "o vehículo personal", false, 0, 0);

        Ruta ruta4 = new Ruta("11,82 Km", "Comienzo: 9:00 - 11:00",
                 "Ciclismo o andando", "No especificado",
                "Senderismo", "Paisaje natural", "Valle de Lecrín",
                "El Valle de Lecrín se encuentra en una zona privilegiada"
                + " de la Península, a los pies de Sierra Nevada, con la Alpujarra"
                + " a un paso, a veinte minutos de la Costa Tropical, y a otros "
                + "veinte de Granada Capital convirtiéndose así en una "
                + "zona excepcional en cuanto a posibilidades de ocio y "
                + "turismo activo.", "Accesible mediante linea de"
                + " bus o vehiculo personal, solo cercanías",
                false, 0, 0);
        
        //creo una instancia para añadir rutas a la base de datos
        DAORuta daoRuta = new DAORuta();
        
//        daoRuta.registrar(ruta1);
//        daoRuta.registrar(ruta2);
//        daoRuta.registrar(ruta3);
//        daoRuta.registrar(ruta4);

        //esto es para eliminar los objetos de la base de datos
//        daoRuta.eliminar(ruta1);
//        daoRuta.eliminar(ruta2);
//        daoRuta.eliminar(ruta3);
//        daoRuta.eliminar(ruta4);
    }
}
