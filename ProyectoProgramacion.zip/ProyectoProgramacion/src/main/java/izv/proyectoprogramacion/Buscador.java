/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package izv.proyectoprogramacion;

import java.util.ArrayList;

/**
 *
 * @author Mañana
 */
public interface Buscador {
    public void buscar(ArrayList<Categoria> objetos, String busqueda);
}
