/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package izv.proyectoprogramacion;

import java.util.ArrayList;

/**
 *
 * @author Mañana
 */
public class Bar extends Ocio{
    
    protected boolean tapasAElegir;
    protected boolean juegosDeMesa;
    protected boolean deportes;

    public Bar(boolean tapasAElegir, boolean juegosDeMesa, boolean deportes, 
            String horario, String servicios, String web, String name, 
            String decripcion, String transporte, Boolean entrada) {
        super(horario, servicios, web, name, decripcion, transporte, entrada);
        this.tapasAElegir = tapasAElegir;
        this.juegosDeMesa = juegosDeMesa;
        this.deportes = deportes;
    }

   

    public boolean isTapasAElegir() {
        return tapasAElegir;
    }

    public void setTapasAElegir(boolean tapasAElegir) {
        this.tapasAElegir = tapasAElegir;
    }

    public boolean isJuegosDeMesa() {
        return juegosDeMesa;
    }

    public void setJuegosDeMesa(boolean juegosDeMesa) {
        this.juegosDeMesa = juegosDeMesa;
    }

    public boolean isDeportes() {
        return deportes;
    }

    public void setDeportes(boolean deportes) {
        this.deportes = deportes;
    }
    
    
    
}
