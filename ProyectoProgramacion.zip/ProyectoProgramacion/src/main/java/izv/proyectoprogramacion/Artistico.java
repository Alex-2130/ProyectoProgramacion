/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package izv.proyectoprogramacion;

import java.util.Objects;

/**
 *
 * @author Mañana
 */
public class Artistico extends Evento{
    
    protected String artista;
    protected String tipo;

    public Artistico(String artista, String tipo, String duracion, String coste, 
            int aforo, String horario, String servicios, String web, String name, 
            String decripcion, String transporte, Boolean entrada) {
        
        super(duracion, coste, aforo, horario, servicios, web, name, decripcion, 
                transporte, entrada);
        
        this.artista = artista;
        this.tipo = tipo;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    
     
    
}
