/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package izv.proyectoprogramacion;

import Users.Valoracion;
import java.util.ArrayList;

/**
 *
 * @author Mañana
 */
public class OcioNocturno extends Ocio{
   
    protected int edad;
    protected String reserva;
    protected String lista;

    public OcioNocturno(int edad, String reserva, String lista, String horario, 
            String servicios, String web, String name, String decripcion, 
            String transporte, Boolean entrada, double latitud, double longitud) {
        super(horario, servicios, web, name, decripcion, transporte, entrada, latitud, longitud);
        this.edad = edad;
        this.reserva = reserva;
        this.lista = lista;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getReserva() {
        return reserva;
    }

    public void setReserva(String reserva) {
        this.reserva = reserva;
    }

    public String getLista() {
        return lista;
    }

    public void setLista(String lista) {
        this.lista = lista;
    }

    
}
