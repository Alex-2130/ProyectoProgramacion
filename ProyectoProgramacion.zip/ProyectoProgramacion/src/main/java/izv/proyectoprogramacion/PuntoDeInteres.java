/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package izv.proyectoprogramacion;

import Users.Valoracion;
import java.util.ArrayList;

/**
 *
 * @author Mañana
 */
public class PuntoDeInteres extends Categoria{
    
    protected String añoFundacion;
    protected String tipo;
    protected String vista;

    public PuntoDeInteres(String añoFundacion, String tipo, String vista, 
            String name, String decripcion, String transporte, Boolean entrada,
            double latitud, double longitud) {
        super(name, decripcion, transporte, entrada, latitud, longitud);
        this.añoFundacion = añoFundacion;
        this.tipo = tipo;
        this.vista = vista;
    }

    public String getAñoFundacion() {
        return añoFundacion;
    }

    public void setAñoFundacion(String añoFundacion) {
        this.añoFundacion = añoFundacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getVista() {
        return vista;
    }

    public void setVista(String vista) {
        this.vista = vista;
    }
    
    
}
