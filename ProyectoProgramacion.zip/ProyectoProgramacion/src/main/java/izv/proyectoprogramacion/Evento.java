/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package izv.proyectoprogramacion;

import java.util.ArrayList;

/**
 *
 * @author Mañana
 */
public class Evento extends Ocio{
    
    protected String duracion;
    protected String coste;
    protected int aforo;

    public Evento(String duracion, String coste, int aforo, String horario, 
            String servicios, String web, String name, String decripcion, 
            String transporte, Boolean entrada) {
        super(horario, servicios, web, name, decripcion, transporte, entrada);
        
        this.duracion = duracion;
        this.coste = coste;
        this.aforo = aforo;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getCoste() {
        return coste;
    }

    public void setCoste(String coste) {
        this.coste = coste;
    }

    public int getAforo() {
        return aforo;
    }

    public void setAforo(int aforo) {
        this.aforo = aforo;
    }
    
    
    
}
