/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

/**
 *
 * @author Rut
 */
public class Coche {
    
    protected String modelo;
    protected String matricula;
    protected String color;

    public Coche(String modelo, String matricula, String color) {
        this.modelo = modelo;
        this.matricula = matricula;
        this.color = color;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Coche: " + modelo + ", Matricula=" + matricula + ", color=" + color;
    }
    
    
    
}
