/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package rut.exafinal_2eval_24_25;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Rut
 */
public class ExaFinal_2Eval_24_25 {

    public static void main(String[] args) {
        System.out.println("**** Examen de la 2 Evaluacion ****");
        pelis();
        System.out.println("---------------------------------");
        herencia();
    }
        
    public static void pelis(){    
        // 1._ Creo un hashmap de películas y lo ordeno 
        // obviamente, lo tendré que pasar a un arraylist porque los hashmap no 
        // tienen orden
        
        HashMap<Film, Double> recaudacion = new HashMap<>();
        newFilm(recaudacion, "El caballero oscuro", 
                new ArrayList<String>(List.of("Christian Bale", 
                        "Heath Ledger")), 152, 6);
        newFilm(recaudacion, "Origen", 
                new ArrayList<String>(List.of("Leonardo DiCaprio", 
                        "Joseph Gordon-Levitt")), 148, 4.98);
        newFilm(recaudacion, "Gladiator", 
                new ArrayList<String>(List.of("Russell Crowe",
                                 " Joaquin Phoenix","Connie Nielsen" )), 
                155, 3.7);
        newFilm(recaudacion, "El silencio de los corderos", 
                new ArrayList<String>(List.of("Jodie Foster"," Anthony Hopkins")), 
                118, 4.5);
        newFilm(recaudacion, "Seven", 
                new ArrayList<String>(List.of("Brad Pitt",
                        " Morgan Freeman","Gwyneth Paltrow", "Kevin Spacey")), 
                127, 2.4);
        newFilm(recaudacion, "Los intocables de Eliot Ness", 
                new ArrayList<String>(List.of("Kevin Costner"," Sean Connery")), 
                119, 4.2);
        
        
        
        // PREGUNTA 2
        // Crear el hashmap de peli, recaudación aleatoria y mostrarlo // 0,5
        
        showRecaudacion(recaudacion);
        
        ArrayList<Film> pelis = new ArrayList<>();
        
        for (Film film : recaudacion.keySet()) {
            pelis.add(film);
        }
        
        // PREGUNTA 3: Ordenación
        // Ordenar las películas por nombre
        // Primero volcamos el hashmap en un arraylist para ordenar
        System.out.println("");
        System.out.println(" ******* PELÍCULAS ORDENADAS POR NOMBRE ***********");
        
        Collections.sort(pelis);
        showFilms(pelis);
        
        System.out.println("");
        System.out.println(" ******* PELÍCULAS ORDENADAS POR RATING DESC ***********");
        
        Collections.sort(pelis, new OrderByRating().reversed());
        showFilms(pelis);

        // PREGUNTA 4
        // Borrar del hashmap las películas con más de 2 actoresç
        System.out.println("");
        System.out.println("*********  BORRAR PELIS CON MÁS DE 2 ACTORES ***************");
        
        borrarPelis(recaudacion);
        showRecaudacion(recaudacion);
        
        
    }
    
    public static void newFilm(HashMap<Film, Double> rec, String title, ArrayList<String> actors, int duration, 
            double rating){
        
        try{
            Film peli = new Film(title, actors, duration, rating);
            rec.put(peli, ThreadLocalRandom.current().nextDouble(1.0, 10000.000001));
            
        }catch (InvalidRatingException ex){
            System.out.println(ex.getMessage());
        }
        
    }
    
    public static void herencia(){
        
        // Creo un HashMap con nombre del conductor y dentro un híbrido enchufable
        // otro total y otro de combustión  --> 0,5
       
        
        // Recorrer el hashmap y ejecutar repostar, enchufar y conducir -->2
       
        
    }
    
    // 0,3 ptos  showRecaudacion
    public static void showRecaudacion(HashMap<Film, Double> rec){
        for (Film peli : rec.keySet()) {
            System.out.println(peli + ". RECAUDACIÓN: " + rec.get(peli));
        }
    }

    
    
    public static void showFilms(ArrayList<Film> pelis){
        for (Film peli : pelis) {
            System.out.println(peli);
        }
    }
    

    // 0,5 borrarPelis
    public static void borrarPelis(HashMap<Film, Double> rec){
        Iterator<Film> it = rec.keySet().iterator();
        
        while(it.hasNext()){
            Film peli = it.next();
            
            if (peli.numActors() > 2) it.remove();
        }
    }
//    color = color.toUpperCase();
//        Iterator<String> it = banderas.keySet().iterator();
//        
//        while(it.hasNext()){
//            int cont = 0;
//            String bandera = it.next();
//            for (String colorBandera : banderas.get(bandera).getColores()) {
//                if(colorBandera.equalsIgnoreCase(color)) cont++;
//            }
//            if(cont>0) it.remove();
//        }
}
