/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

import java.util.Comparator;

/**
 *
 * @author Mañana
 */
public class OrderByRating implements Comparator<Film>{

    @Override
    public int compare(Film o1, Film o2) {
        if (o1.getRating() == o2.getRating()) return 0;
        else if (o1.getRating() < o2.getRating()) return -1;
        else return 1;
    }
    
}
