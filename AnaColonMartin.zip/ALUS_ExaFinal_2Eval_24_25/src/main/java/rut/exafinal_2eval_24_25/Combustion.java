/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

/**
 *
 * @author Mañana
 */
public class Combustion extends Coche{
    protected final double capacidad;
    
    public Combustion(Double capacidad, String modelo, String matricula, String color) {
        super(modelo, matricula, color);
        this.capacidad = capacidad;
    }
    
}
