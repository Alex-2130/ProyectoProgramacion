/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Mañana
 */
public class Hibrido extends Coche{
    protected int autonomiaReal;
    protected final int autonomiaTotal;
    protected boolean esEnchufable;
    
    public Hibrido(int autonomiaTotal, String modelo, String matricula, 
            String color) {
        super(modelo, matricula, color);
        this.autonomiaTotal = autonomiaTotal;
        setAutonomiaReal();
    }

    public boolean getEsEnchufable() {
        return esEnchufable;
    }

    public void setEsEnchufable(boolean esEnchufable) {
        this.esEnchufable = esEnchufable;
    }
    

    public int getAutonomiaTotal() {
        return autonomiaTotal;
    }
    
    public int getAutonomiaReal() {
        return autonomiaReal;
    }

    public void setAutonomiaReal() {
        autonomiaReal = ThreadLocalRandom.current().nextInt(1,(autonomiaTotal/2)+1);
    }

    @Override
    public String toString() {
        return super.toString() +  ". Autonomia real: " + autonomiaReal + 
                " kms de " + autonomiaTotal;
    }
    
    
    
}
