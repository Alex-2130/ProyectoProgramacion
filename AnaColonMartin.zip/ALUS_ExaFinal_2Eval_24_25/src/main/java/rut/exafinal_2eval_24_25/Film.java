/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rut
 */


public class Film implements Comparable{  

    protected String title;
    protected ArrayList<String> actors;
    protected int duration;
    protected double rating; // Entre 1 y 5, por defecto 0.

    public Film(String title, ArrayList<String> actors, int duration, double rating) 
            throws InvalidRatingException{
        this.title = title.toUpperCase();
        this.actors = actors;
        this.duration = duration;
        this.rating = 0;
        
        setRating(rating);
        
        
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ArrayList<String> getActors() {
        return actors;
    }

    public void setActors(ArrayList<String> actors) {
        this.actors = actors;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public double getRating() {
        return rating;
    }
    
    //0,3 setRating
    public void setRating(double rating) throws InvalidRatingException{
        if (rating>=0 && rating <=5) this.rating = rating;
        else throw new InvalidRatingException("Invalid rating");
    }
    
    public int numActors(){
        return actors.size();
    }
    
    

    @Override
    public String toString() {
        String phrase = title + ". Con ";
        
        for (int i = 0; i < actors.size(); i++) {
            if (i == actors.size()-1)
                phrase += " " + actors.get(i);
            else if (i == actors.size()-2)
                phrase += actors.get(i) + " y ";
            else 
                phrase += actors.get(i) + ", ";
        }
        
        phrase += ". Duración: " + duration + " mins. Rating --> " + rating;
        
        return phrase;
    }

    //orden natural
    @Override
    public int compareTo(Object o) {
        Film film = (Film) o;
        return this.title.compareToIgnoreCase(film.title);
    }

    
    

   


}
