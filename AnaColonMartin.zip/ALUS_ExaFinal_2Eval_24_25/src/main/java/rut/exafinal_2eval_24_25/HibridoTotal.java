/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

/**
 *
 * @author Mañana
 */
public class HibridoTotal extends Hibrido{
    
    public HibridoTotal(int autonomiaTotal, String modelo, String matricula, String color) {
        super(autonomiaTotal, modelo, matricula, color);
        esEnchufable = false;
    }
    
    public void conducir(int mins, String tipo){
        if(mins > 0){
            if (tipo.equalsIgnoreCase("ciudad"))
                autonomiaReal -= 1.5*mins;
            else if(tipo.equalsIgnoreCase("carretera"))
                autonomiaReal -= 0.5*mins;
            else if (tipo.equalsIgnoreCase("autovia"))
                autonomiaReal -= 3*mins;
            else
                System.out.println("tipo de via inválido");
        } else{
            System.out.println("minutos incorrectos");
        }   
    }

    @Override
    public String toString() {
        return "HIBRIDO TOTAL: " + modelo + ", " + matricula + " de color "
                + color + ". Quedan "+ autonomiaReal+ " de " + autonomiaTotal;
    }
    
    
}
