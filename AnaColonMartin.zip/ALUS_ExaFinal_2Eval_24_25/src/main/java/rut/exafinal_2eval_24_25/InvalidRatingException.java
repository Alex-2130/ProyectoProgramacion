/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

/**
 *
 * @author Mañana
 */
public class InvalidRatingException extends Exception{

    public InvalidRatingException(String message) {
        super(message);
    }
    
}
