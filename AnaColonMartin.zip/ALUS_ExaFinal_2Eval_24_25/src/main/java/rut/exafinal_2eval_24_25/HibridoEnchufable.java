/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rut.exafinal_2eval_24_25;

/**
 *
 * @author Mañana
 */
public class HibridoEnchufable extends Hibrido{
    
    public HibridoEnchufable(int autonomiaTotal, String modelo, String matricula, String color) {
        super(autonomiaTotal, modelo, matricula, color);
        esEnchufable = true;
    }
    
    public void enchufar(int mins){
        if (mins<=0)
            System.out.println("autonomia no válida");
        else if (mins<=15)
            autonomiaReal += 1;
        else if (mins<=30)
            autonomiaReal += 6;
        else if(mins<=60)
            autonomiaReal += 10;
        else if(mins <= 240)
            autonomiaReal = autonomiaTotal;
    }

    @Override
    public String toString() {
        return "HIBRIDO ENCHUFABLE: " + modelo + ", " + matricula + ", de color "
                + "color. Quedan" + autonomiaReal + " kms de " + autonomiaTotal;
    }
    
    
}
